#[cfg(Py_LIMITED_API)]
opaque_struct!(PyCodeObject);
