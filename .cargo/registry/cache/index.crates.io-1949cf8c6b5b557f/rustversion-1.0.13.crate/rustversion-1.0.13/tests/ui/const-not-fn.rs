#[rustversion::attr(all(), const)]
pub struct S;

fn main() {}
